.pragma library

// Využití JavaScriptu pro definování stylu
var slider_color = "steelBlue";
var btn_colour = "#bbbbbb";
